"""Today workspace composition."""
