from __future__ import annotations

import re

from sqlalchemy import func, or_

from app.extensions import db
from app.youtube.models import YouTubeVideo


class YouTubeRepository:
    @staticmethod
    def get(video_id: str) -> YouTubeVideo | None:
        return db.session.get(YouTubeVideo, video_id)

    @staticmethod
    def get_by_source_external_id(source: str, external_id: str) -> YouTubeVideo | None:
        return db.session.scalar(
            db.select(YouTubeVideo).where(
                YouTubeVideo.source == source,
                YouTubeVideo.external_id == external_id,
            )
        )

    @staticmethod
    def list(
        *,
        source: str,
        group: str = "",
        q: str = "",
        limit: int | None = 50,
        offset: int = 0,
    ) -> tuple[list[YouTubeVideo], int]:
        conditions = [
            YouTubeVideo.source == source,
            YouTubeVideo.removed_from_source.is_(False),
        ]
        if group:
            conditions.append(YouTubeVideo.group_name == group)
        if q.strip():
            pattern = f"%{q.strip().lower()}%"
            conditions.append(
                or_(
                    func.lower(YouTubeVideo.title).like(pattern),
                    func.lower(YouTubeVideo.channel_title).like(pattern),
                )
            )
        base = db.select(YouTubeVideo).where(*conditions)
        total = int(
            db.session.scalar(
                db.select(func.count()).select_from(YouTubeVideo).where(*conditions)
            )
            or 0
        )
        query = base.order_by(YouTubeVideo.position, YouTubeVideo.published_at.desc())
        if limit is not None:
            query = query.limit(limit)
        if offset:
            query = query.offset(offset)
        items = list(db.session.scalars(query))
        return items, total

    @staticmethod
    def resolve_group(value: str) -> str:
        requested = value.strip()
        if not requested:
            return ""
        groups = YouTubeRepository.groups()
        by_exact = {item["name"]: item["name"] for item in groups}
        if requested in by_exact:
            return by_exact[requested]
        requested_key = _group_key(requested)
        for item in groups:
            if _group_key(item["name"]) == requested_key:
                return item["name"]
        return ""

    @staticmethod
    def ordered_ids(*, source: str, group: str = "") -> list[str]:
        conditions = [
            YouTubeVideo.source == source,
            YouTubeVideo.removed_from_source.is_(False),
        ]
        if group:
            conditions.append(YouTubeVideo.group_name == group)
        return list(
            db.session.scalars(
                db.select(YouTubeVideo.id)
                .where(*conditions)
                .order_by(YouTubeVideo.position, YouTubeVideo.published_at.desc())
            )
        )

    @staticmethod
    def groups() -> list[dict]:
        rows = db.session.execute(
            db.select(YouTubeVideo.group_name, func.count())
            .where(
                YouTubeVideo.source == "pockettube",
                YouTubeVideo.group_name != "",
                YouTubeVideo.removed_from_source.is_(False),
            )
            .group_by(YouTubeVideo.group_name)
            .order_by(YouTubeVideo.group_name)
        )
        return [{"name": name, "count": count} for name, count in rows]


def _group_key(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "", value.casefold())
    return normalized.replace("favorite", "favoret")
