from __future__ import annotations

from typing import Any

from sqlalchemy import String, case, cast, func, or_
from sqlalchemy.orm import selectinload

from app.extensions import db
from app.movies.models import Movie, MovieLibraryEntry, MovieProgress

SORTS = {
    "title_asc": Movie.normalized_title.asc(),
    "title_desc": Movie.normalized_title.desc(),
    "score_desc": func.coalesce(
        MovieLibraryEntry.personal_rating,
        Movie.personal_score,
    ).desc().nullslast(),
    "year_desc": Movie.year.desc().nullslast(),
    "recently_updated": Movie.updated_at.desc(),
}


def _lifecycle_status_column():
    return case(
        (MovieLibraryEntry.lifecycle_status.is_not(None), MovieLibraryEntry.lifecycle_status),
        (Movie.status.in_(("finished", "watched")), "watched"),
        (Movie.status == "watching", "watching"),
        else_="want_to_watch",
    )


def library_options():
    return (
        selectinload(Movie.library_entry),
        selectinload(Movie.progress),
        selectinload(Movie.progress_entries),
    )


class MovieRepository:
    @staticmethod
    def get(movie_id: str) -> Movie | None:
        return db.session.scalar(
            db.select(Movie)
            .options(*library_options())
            .where(Movie.id == movie_id)
        )

    @staticmethod
    def list(
        filters: dict[str, Any],
        *,
        limit: int,
        offset: int,
        library_ids: list[str] | None = None,
    ) -> tuple[list[Movie], int]:
        lifecycle_status = _lifecycle_status_column()
        query = (
            db.select(Movie)
            .outerjoin(MovieLibraryEntry, MovieLibraryEntry.movie_id == Movie.id)
            .options(*library_options())
        )
        count_query = (
            db.select(func.count())
            .select_from(Movie)
            .outerjoin(MovieLibraryEntry, MovieLibraryEntry.movie_id == Movie.id)
        )
        conditions = []
        if library_ids is not None:
            conditions.append(Movie.id.in_(library_ids))
        search = str(filters.get("q") or "").strip().lower()
        if search:
            pattern = f"%{search}%"
            conditions.append(
                or_(
                    Movie.normalized_title.like(pattern),
                    func.lower(Movie.original_title).like(pattern),
                )
            )
        for key, column in (("category", Movie.category), ("source", Movie.source)):
            value = str(filters.get(key) or "").strip()
            if value:
                conditions.append(column == value)
        status = str(filters.get("status") or "").strip()
        if status:
            conditions.append(lifecycle_status == ("watched" if status == "finished" else status))
        genre = str(filters.get("genre") or "").strip().lower()
        if genre:
            conditions.append(func.lower(cast(Movie.genres, String)).like(f'%"{genre}"%'))
        if filters.get("year_min") is not None:
            conditions.append(Movie.year >= filters["year_min"])
        if filters.get("year_max") is not None:
            conditions.append(Movie.year <= filters["year_max"])
        if filters.get("score_min") is not None:
            conditions.append(
                func.coalesce(MovieLibraryEntry.personal_rating, Movie.personal_score)
                >= filters["score_min"]
            )
        if filters.get("score_max") is not None:
            conditions.append(
                func.coalesce(MovieLibraryEntry.personal_rating, Movie.personal_score)
                <= filters["score_max"]
            )
        if filters.get("hide_completed"):
            conditions.append(lifecycle_status != "watched")
        if filters.get("favorite"):
            conditions.append(MovieLibraryEntry.is_favorite.is_(True))
        if conditions:
            query = query.where(*conditions)
            count_query = count_query.where(*conditions)
        total = int(db.session.scalar(count_query) or 0)
        order = SORTS.get(str(filters.get("sort") or ""), Movie.updated_at.desc())
        items = list(db.session.scalars(query.order_by(order).limit(limit).offset(offset)))
        return items, total

    @staticmethod
    def continue_watching(*, limit: int = 6, library_ids: list[str] | None = None) -> list[Movie]:
        lifecycle_status = _lifecycle_status_column()
        query = (
            db.select(Movie)
            .join(MovieProgress, MovieProgress.movie_id == Movie.id)
            .outerjoin(MovieLibraryEntry, MovieLibraryEntry.movie_id == Movie.id)
            .options(*library_options())
            .where(
                MovieProgress.current_seconds > 0,
                MovieProgress.completed.is_(False),
                lifecycle_status != "watched",
            )
            .order_by(MovieProgress.updated_at.desc())
            .limit(limit)
        )
        if library_ids is not None:
            query = query.where(Movie.id.in_(library_ids))
        return list(db.session.scalars(query).unique())

    @staticmethod
    def watch_next(*, limit: int = 24, library_ids: list[str] | None = None) -> list[Movie]:
        lifecycle_status = _lifecycle_status_column()
        query = (
            db.select(Movie)
            .outerjoin(MovieLibraryEntry, MovieLibraryEntry.movie_id == Movie.id)
            .options(*library_options())
            .where(lifecycle_status == "want_to_watch")
            .order_by(
                func.coalesce(
                    MovieLibraryEntry.personal_rating,
                    Movie.personal_score,
                ).desc().nullslast(),
                Movie.runtime_minutes.asc().nullslast(),
                Movie.updated_at.desc(),
            )
            .limit(limit)
        )
        if library_ids is not None:
            query = query.where(Movie.id.in_(library_ids))
        return list(db.session.scalars(query))

    @staticmethod
    def notion_library_ids() -> list[str]:
        ids = []
        for movie in db.session.scalars(db.select(Movie)):
            external_ids = dict(movie.external_ids or {})
            metadata = dict(movie.metadata_state or {})
            if external_ids.get("notion_page_id") or metadata.get("library_origin") == "notion":
                ids.append(movie.id)
        return ids

    @staticmethod
    def filter_options(library_ids: list[str] | None = None) -> dict[str, list[str]]:
        def values(column):
            query = db.select(column).where(column != "").distinct().order_by(column)
            if library_ids is not None:
                query = query.where(Movie.id.in_(library_ids))
            return [str(value) for value in db.session.scalars(query) if value]

        genres: set[str] = set()
        genre_query = db.select(Movie.genres)
        if library_ids is not None:
            genre_query = genre_query.where(Movie.id.in_(library_ids))
        for movie_genres in db.session.scalars(genre_query):
            for genre in movie_genres or []:
                name = genre.get("name") if isinstance(genre, dict) else genre
                if name:
                    genres.add(str(name))
        return {
            "statuses": ["want_to_watch", "watching", "watched"],
            "categories": values(Movie.category),
            "sources": values(Movie.source),
            "genres": sorted(genres, key=str.casefold),
        }
