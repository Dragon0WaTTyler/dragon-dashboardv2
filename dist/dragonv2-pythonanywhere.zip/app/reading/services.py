from __future__ import annotations

import hashlib
from contextlib import suppress
from datetime import timedelta
from urllib.parse import urlsplit

from flask import current_app
from sqlalchemy import or_

from app.extensions import db
from app.history.services import HistoryService
from app.reading.models import Article, ReadingSource
from app.reading.text import article_paragraphs, normalize_article_text
from app.shared.models import SnapshotRecord
from app.shared.operations.service import safe_error_text
from app.shared.text import text_direction
from app.shared.time import utc_iso, utc_now

ARTICLE_STATUSES = {"unread", "reading", "finished"}
READING_CACHE_LIMIT = 200
PROTECTED_READING_STATUSES = {"reading"}


def article_item(article: Article) -> dict:
    return {
        "id": article.id,
        "title": article.title,
        "url": article.url,
        "direction": text_direction(article.title),
        "source": article.source.name if article.source else "Unknown source",
        "source_id": article.source_id,
        "author": article.author,
        "topic": article.topic,
        "excerpt": normalize_article_text(article.excerpt),
        "image_url": article.image_url,
        "status": article.status,
        "is_saved": article.is_saved,
        "published_at": article.published_at.isoformat() if article.published_at else None,
        "fulltext_state": article.fulltext_state,
    }


def article_detail(article: Article) -> dict:
    item = article_item(article)
    content_paragraphs = article_paragraphs(article.content_text, title=article.title)
    content_text = "\n\n".join(content_paragraphs)
    is_video = "/video/" in urlsplit(article.url).path.casefold()
    return {
        **item,
        "url": article.url,
        "content_text": content_text,
        "content_paragraphs": content_paragraphs,
        "content_blocks": list(article.content_blocks or []),
        "content_kind": "video" if is_video else "article",
        "content_label": "Video summary" if is_video else "Full article",
        "language": "ar" if item["direction"] == "rtl" else "en",
        "fulltext_error": article.fulltext_error,
        "history": article.history,
    }


def article_content_is_readable(article: Article) -> bool:
    if any(
        isinstance(block, dict) and block.get("kind") != "text"
        for block in article.content_blocks or []
    ):
        return True
    paragraphs = article_paragraphs(article.content_text, title=article.title)
    return any(len(paragraph) >= 80 for paragraph in paragraphs)


class ReadingService:
    @staticmethod
    def continue_reading(limit: int = 4) -> list[dict]:
        from app.reading.repositories import ReadingRepository

        articles = ReadingRepository.list(status="reading", limit=limit)
        return [article_item(article) for article in articles]

    @staticmethod
    def latest_news_mix(limit: int = 24) -> list[dict]:
        from app.reading.repositories import ReadingRepository

        articles = ReadingRepository.list(limit=limit)
        return [article_item(article) for article in articles]

    @staticmethod
    def article_of_day() -> dict | None:
        from app.reading.repositories import ReadingRepository

        articles = ReadingRepository.list(status="unread", limit=1)
        return article_item(articles[0]) if articles else None

    @staticmethod
    def extract_fulltext(article: Article, extractor) -> None:
        try:
            result = extractor.extract(article.url)
            content = normalize_article_text(result.get("content_text"))
            content_blocks = [
                block for block in (result.get("content_blocks") or []) if isinstance(block, dict)
            ]
            content = "\n\n".join(article_paragraphs(content, title=article.title))
            if not content and not any(block.get("kind") != "text" for block in content_blocks):
                raise ValueError("Extractor returned no readable text.")
        except Exception as exc:
            article.fulltext_state = "failed"
            article.fulltext_error = safe_error_text(exc)
            db.session.commit()
            raise ValueError("Full-text extraction failed safely.") from exc
        article.content_text = content[:1_000_000]
        article.content_blocks = content_blocks
        article.fulltext_state = "cached"
        article.fulltext_error = ""
        if article.status == "unread":
            article.status = "reading"
        article.history = [*article.history, {"event": "fulltext_cached", "at": utc_iso()}]
        HistoryService.record(
            domain="reading",
            entity_type="article",
            entity_id=article.id,
            event_type="fulltext_cached",
            label=f"Cached full text for {article.title}",
        )
        db.session.commit()

    @staticmethod
    def set_status(article: Article, status: str) -> None:
        if status not in ARTICLE_STATUSES:
            raise ValueError("Unknown reading status.")
        article.status = status
        article.history = [*article.history, {"event": status, "at": utc_iso()}]
        HistoryService.record(
            domain="reading",
            entity_type="article",
            entity_id=article.id,
            event_type="status",
            label=f"{article.title}: {status}",
        )
        db.session.commit()

    @staticmethod
    def set_saved(article: Article, saved: bool) -> None:
        article.is_saved = saved
        article.history = [
            *article.history,
            {"event": "saved" if saved else "unsaved", "at": utc_iso()},
        ]
        HistoryService.record(
            domain="reading",
            entity_type="article",
            entity_id=article.id,
            event_type="saved" if saved else "unsaved",
            label=f"{article.title}: {'saved' if saved else 'removed from saved'}",
        )
        db.session.commit()

    @staticmethod
    def extraction_status(article: Article) -> dict:
        return {
            "article_id": article.id,
            "state": article.fulltext_state,
            "error": article.fulltext_error or None,
            "cached": bool(article.content_text),
        }

    @staticmethod
    def sync_sources(client, *, source_ids: set[str] | None = None) -> dict[str, int]:
        query = db.select(ReadingSource).where(ReadingSource.active.is_(True))
        if source_ids is not None:
            query = query.where(ReadingSource.id.in_(source_ids))
        sources = list(db.session.scalars(query.order_by(ReadingSource.name)))
        counts = {
            "sources": len(sources),
            "sources_synced": 0,
            "sources_failed": 0,
            "created": 0,
            "updated": 0,
            "changed": 0,
            "trimmed": 0,
        }
        seen: set[str] = set()
        for source in sources:
            try:
                result = client.fetch(source.feed_url)
                entries = list(result.get("entries") or [])
            except Exception as exc:
                source.health_state = "error"
                source.health_message = safe_error_text(exc)
                counts["sources_failed"] += 1
                continue

            for entry in entries:
                external_id = str(entry.get("external_id") or entry.get("url") or "")[:500]
                article_url = str(entry.get("url") or "")[:1500]
                if not external_id or not article_url:
                    continue
                seen.add(f"{source.id}:{external_id}")
                article = db.session.scalar(
                    db.select(Article).where(
                        Article.source_id == source.id,
                        or_(Article.external_id == external_id, Article.url == article_url),
                    )
                )
                values = {
                    "external_id": external_id,
                    "title": str(entry.get("title") or "Untitled article")[:600],
                    "url": article_url,
                    "author": str(entry.get("author") or "")[:240],
                    "topic": str(entry.get("topic") or "")[:160],
                    "excerpt": str(entry.get("excerpt") or "")[:20_000],
                    "image_url": (
                        str(entry.get("image_url") or "")[:1000] if source.download_images else ""
                    ),
                    "published_at": entry.get("published_at"),
                }
                if article is None:
                    article = Article(source=source, **values)
                    db.session.add(article)
                    counts["created"] += 1
                else:
                    changed = False
                    for field, value in values.items():
                        if getattr(article, field) != value:
                            setattr(article, field, value)
                            changed = True
                    if changed:
                        counts["updated"] += 1
                if source.download_fulltext:
                    extractor = current_app.extensions.get("dragon_article_extractor")
                    if extractor is not None:
                        db.session.flush()
                        with suppress(ValueError):
                            ReadingService.extract_fulltext(article, extractor)

            source.health_state = "healthy"
            source.health_message = f"Synced {len(entries)} feed entries."
            source.last_success_at = utc_now()
            counts["sources_synced"] += 1
            counts["trimmed"] += ReadingService.trim_source_cache(
                source.id, maximum=source.maximum_articles
            )

        counts["changed"] = counts["created"] + counts["updated"]
        checksum = hashlib.sha256("\n".join(sorted(seen)).encode()).hexdigest()
        snapshot = db.session.scalar(
            db.select(SnapshotRecord).where(SnapshotRecord.domain == "reading")
        )
        now = utc_now()
        if snapshot is None:
            snapshot = SnapshotRecord(
                domain="reading",
                schema_version="reading-feed-cache-v1",
                relative_path="database://articles",
                checksum=checksum,
                generated_at=now,
                last_success_at=now,
            )
            db.session.add(snapshot)
        snapshot.schema_version = "reading-feed-cache-v1"
        snapshot.relative_path = "database://articles"
        snapshot.checksum = checksum
        snapshot.state = "fresh"
        snapshot.message = f"{counts['changed']} article changes synchronized."
        snapshot.generated_at = now
        snapshot.last_success_at = now
        db.session.commit()
        return counts

    @staticmethod
    def trim_source_cache(source_id: str, *, maximum: int) -> int:
        articles = list(
            db.session.scalars(
                db.select(Article)
                .where(Article.source_id == source_id)
                .order_by(Article.published_at.desc(), Article.created_at.desc())
            )
        )
        if len(articles) <= maximum:
            return 0
        protected = {
            article.id
            for article in articles
            if article.status in PROTECTED_READING_STATUSES or article.is_saved
        }
        remaining_slots = max(0, maximum - len(protected))
        kept_ids = set(protected)
        for article in articles:
            if article.id in kept_ids:
                continue
            if remaining_slots <= 0:
                break
            kept_ids.add(article.id)
            remaining_slots -= 1
        trimmed = 0
        for article in articles:
            if article.id not in kept_ids:
                db.session.delete(article)
                trimmed += 1
        return trimmed

    @staticmethod
    def trim_by_age(*, days: int, protect_saved: bool = True) -> int:
        cutoff = utc_now() - timedelta(days=days)
        query = db.select(Article).where(Article.created_at < cutoff)
        if protect_saved:
            query = query.where(
                Article.status.not_in(PROTECTED_READING_STATUSES), Article.is_saved.is_(False)
            )
        articles = list(db.session.scalars(query))
        for article in articles:
            db.session.delete(article)
        return len(articles)

    @staticmethod
    def trim_cache(*, maximum: int = READING_CACHE_LIMIT) -> int:
        articles = list(
            db.session.scalars(
                db.select(Article).order_by(Article.published_at.desc(), Article.created_at.desc())
            )
        )
        if len(articles) <= maximum:
            return 0

        protected = [
            article
            for article in articles
            if article.status in PROTECTED_READING_STATUSES or article.is_saved
        ]
        remaining_slots = max(0, maximum - len(protected))
        kept_ids = {article.id for article in protected}
        for article in articles:
            if article.id in kept_ids:
                continue
            if remaining_slots <= 0:
                break
            kept_ids.add(article.id)
            remaining_slots -= 1

        trimmed = 0
        for article in articles:
            if article.id not in kept_ids:
                db.session.delete(article)
                trimmed += 1
        return trimmed
