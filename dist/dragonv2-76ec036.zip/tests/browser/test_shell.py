import re

import pytest

from app.books.models import Book
from app.extensions import db
from app.movies.models import Movie
from app.reading.models import Article, ReadingSource
from app.youtube.models import YouTubeVideo

pytestmark = pytest.mark.browser


def sign_in(page, base_url: str):
    page.goto(f"{base_url}/auth/login")
    page.get_by_label("Username").fill("walid")
    page.get_by_label("Password").fill("correct horse battery staple")
    page.get_by_role("button", name="Sign in").click()
    page.wait_for_url(f"{base_url}/")


def test_desktop_shell_keyboard_and_dialog(page, live_app):
    page.set_viewport_size({"width": 1440, "height": 900})
    sign_in(page, live_app)
    assert page.get_by_role("heading", name="Today", level=1).count() == 1
    assert page.locator("main").count() == 1
    assert page.locator("nav[aria-label='Primary navigation']").count() == 1

    trigger = page.get_by_role("button", name=re.compile("Search or open"))
    trigger.focus()
    page.keyboard.press("Enter")
    dialog = page.get_by_role("dialog", name="Where do you want to go?")
    assert dialog.is_visible()
    page.keyboard.press("Escape")
    assert not dialog.is_visible()
    assert trigger.evaluate("element => element === document.activeElement")


def test_today_supporting_blocks_use_the_desktop_sidebar(page, live_app):
    page.set_viewport_size({"width": 1440, "height": 900})
    sign_in(page, live_app)

    grid = page.locator(".today-grid--custom-layout")
    desktop = grid.evaluate(
        """element => {
          const main = element.querySelector('.today-main').getBoundingClientRect();
          const aside = element.querySelector('.today-aside').getBoundingClientRect();
          return {
            columns: getComputedStyle(element).gridTemplateColumns.split(' ').length,
            mainRight: main.right,
            asideLeft: aside.left,
            mainTop: main.top,
            asideTop: aside.top,
          };
        }"""
    )
    assert desktop["columns"] == 2
    assert desktop["asideLeft"] > desktop["mainRight"]
    assert abs(desktop["asideTop"] - desktop["mainTop"]) <= 1

    page.set_viewport_size({"width": 800, "height": 900})
    mobile = grid.evaluate(
        """element => {
          const main = element.querySelector('.today-main').getBoundingClientRect();
          const aside = element.querySelector('.today-aside').getBoundingClientRect();
          return {
            columns: getComputedStyle(element).gridTemplateColumns.split(' ').length,
            mainBottom: main.bottom,
            asideTop: aside.top,
            hasOverflow:
              document.documentElement.scrollWidth > document.documentElement.clientWidth,
          };
        }"""
    )
    assert mobile["columns"] == 1
    assert mobile["asideTop"] >= mobile["mainBottom"]
    assert not mobile["hasOverflow"]


def test_mobile_shell_has_no_overflow_and_safe_targets(page, live_app):
    page.set_viewport_size({"width": 390, "height": 844})
    sign_in(page, live_app)
    metrics = page.evaluate(
        """() => ({
          scrollWidth: document.documentElement.scrollWidth,
          clientWidth: document.documentElement.clientWidth,
          appBarTops: [
            document.querySelector('.brand'),
            document.querySelector('.command-trigger'),
            document.querySelector('.account-menu'),
          ].map((element) => Math.round(element.getBoundingClientRect().top)),
          smallTargets: [...document.querySelectorAll('a[href], button, input, select')]
            .filter((element) => {
              const rect = element.getBoundingClientRect();
              return rect.width > 0 && rect.height > 0 && (rect.width < 44 || rect.height < 44);
            })
            .map((element) => element.textContent.trim()).slice(0, 10),
        })"""
    )
    assert metrics["scrollWidth"] == metrics["clientWidth"]
    assert max(metrics["appBarTops"]) - min(metrics["appBarTops"]) <= 2
    assert metrics["smallTargets"] == []
    assert page.locator("nav[aria-label='Mobile navigation']").is_visible()


def test_login_and_design_system_semantics(page, live_app):
    page.set_viewport_size({"width": 390, "height": 844})
    page.goto(f"{live_app}/auth/login")
    assert page.get_by_role("heading", name="Enter the archive.", level=1).count() == 1
    assert page.get_by_label("Username").count() == 1
    assert page.get_by_label("Password").count() == 1
    sign_in(page, live_app)
    page.goto(f"{live_app}/admin/design-system")
    assert page.get_by_role("heading", name="Design system", level=1).count() == 1
    assert page.locator("[style]").count() == 0


def test_library_grid_thumbnails_and_rtl_direction(page, live_app, app):
    image = (
        "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' "
        "width='40' height='60'%3E%3Crect width='40' height='60' fill='%23b51f32'/%3E%3C/svg%3E"
    )
    with app.app_context():
        source = ReadingSource(name="مجلة", feed_url="https://example.test/feed")
        db.session.add_all(
            [
                Book(
                    title="كتاب عربي",
                    normalized_title="كتاب عربي",
                    authors=["كاتب"],
                    cover_url=image,
                    status="reading",
                ),
                Article(
                    source=source,
                    title="مقال عربي",
                    url="https://example.test/article",
                    image_url=image,
                ),
                Movie(
                    title="Daily Movie",
                    normalized_title="daily movie",
                    status="want_to_watch",
                    poster_url=image,
                ),
                YouTubeVideo(
                    external_id="home-video",
                    source="watch_later",
                    channel_title="Home Channel",
                    title="فيديو عربي",
                    thumbnail_url=image,
                    duration_seconds=4112,
                ),
            ]
        )
        db.session.commit()

    sign_in(page, live_app)
    page.goto(f"{live_app}/books")
    display = page.locator(".book-grid").evaluate(
        "element => getComputedStyle(element).display"
    )
    assert display == "grid"
    column_count = page.locator(".book-grid").evaluate(
        "element => getComputedStyle(element).gridTemplateColumns.split(' ').length"
    )
    assert column_count == 5
    assert page.locator(".book-cover img").is_visible()
    book_card_metrics = page.locator(".book-card").first.evaluate(
        "element => ({"
        "cardWidth: element.getBoundingClientRect().width,"
        "badgeWidth: element.querySelector('.badge').getBoundingClientRect().width"
        "})"
    )
    assert book_card_metrics["badgeWidth"] < book_card_metrics["cardWidth"]
    assert page.locator(".book-card h2").evaluate(
        "element => getComputedStyle(element).direction"
    ) == "rtl"

    page.set_viewport_size({"width": 390, "height": 844})
    mobile_column_count = page.locator(".book-grid").evaluate(
        "element => getComputedStyle(element).gridTemplateColumns.split(' ').length"
    )
    assert mobile_column_count == 2
    page.set_viewport_size({"width": 1280, "height": 720})

    page.goto(f"{live_app}/reading")
    assert page.locator(".article-card__image img").is_visible()
    assert page.locator(".article-list--grid").evaluate(
        "element => getComputedStyle(element).gridTemplateColumns.split(' ').length"
    ) == 3
    assert page.locator(".article-card h2").evaluate(
        "element => getComputedStyle(element).direction"
    ) == "rtl"
    page.locator(".news-filters summary").click()
    page.get_by_label("View").select_option("list")
    page.get_by_role("button", name="Apply").click()
    assert page.locator(".article-list--grid").count() == 0
    assert page.locator(".article-card--rtl").evaluate(
        "element => element.querySelector('.article-card__image').getBoundingClientRect().left"
        " > element.getBoundingClientRect().left + element.getBoundingClientRect().width / 2"
    )

    page.goto(f"{live_app}/youtube")
    assert page.locator(".media-list--grid").evaluate(
        "element => getComputedStyle(element).gridTemplateColumns.split(' ').length"
    ) == 3
    duration = page.locator(".media-duration").first
    assert duration.inner_text() == "1:08:32"
    assert duration.evaluate(
        "element => getComputedStyle(element).fontVariantNumeric.includes('tabular-nums')"
    )
    page.get_by_label("View").select_option("list")
    page.get_by_role("button", name="Apply").click()
    assert page.locator(".media-list--grid").count() == 0
    assert page.locator(".media-row--rtl").evaluate(
        "element => element.querySelector('.media-row__image').getBoundingClientRect().left"
        " > element.getBoundingClientRect().left + element.getBoundingClientRect().width / 2"
    )

    page.route(
        "**/api/v1/home/live",
        lambda route: route.fulfill(
            json={
                "ok": True,
                "api_version": "v1",
                "item": {
                    "recommended_movie": {
                        "id": "rotated-movie",
                        "title": "Rotated Movie",
                        "year": 2026,
                        "personal_score": 5,
                        "poster_url": image,
                    },
                    "latest_youtube": [
                        {
                            "id": "rotated-video",
                            "title": "Rotated video",
                            "channel_title": "Rotated Channel",
                            "thumbnail_url": image,
                            "duration_label": "12:47",
                        }
                    ],
                    "rotation": {
                        "movie_bucket": 999999,
                        "youtube_bucket": 999999,
                        "movie_interval_seconds": 3600,
                        "youtube_interval_seconds": 300,
                        "movie_next_at": "2099-01-01T01:00:00Z",
                        "youtube_next_at": "2099-01-01T00:05:00Z",
                    },
                },
            }
        ),
    )
    page.goto(f"{live_app}/")
    assert page.locator(".today-feature__poster img").is_visible()
    assert page.locator(".today-media-card__image img").is_visible()
    assert page.locator(".today-article-feature__image img").is_visible()
    assert page.locator(".today-book__cover img").is_visible()
    page.locator("[data-today-live]").dispatch_event("today:refresh")
    page.get_by_text("Rotated Movie", exact=True).wait_for()
    assert page.locator("[data-live-youtube-title]").first.inner_text() == "Rotated video"
    assert page.locator("[data-live-youtube-duration]").first.inner_text() == "12:47"


def test_movie_recommendation_and_more_filters_stay_in_flow(page, live_app, app):
    with app.app_context():
        db.session.add_all(
            [
                Movie(
                    title="In the Mood for Love",
                    normalized_title="in the mood for love",
                    status="finished",
                    personal_score=8,
                    category="movie",
                    source="My library",
                    directors=[{"name": "Wong Kar-wai"}],
                    genres=[{"name": "Drama"}],
                ),
                Movie(
                    title="Chungking Express",
                    normalized_title="chungking express",
                    year=1994,
                    runtime_minutes=102,
                    status="want_to_watch",
                    category="movie",
                    source="My library",
                    overview="Two stories of love and chance in Hong Kong.",
                    poster_url="https://example.test/chungking.jpg",
                    directors=[{"name": "Wong Kar-wai"}],
                    genres=[{"name": "Drama"}],
                ),
                Movie(
                    title="Happy Together",
                    normalized_title="happy together",
                    year=1997,
                    runtime_minutes=96,
                    status="want_to_watch",
                    category="movie",
                    source="My library",
                    overview="A relationship shifts during a journey to Argentina.",
                    poster_url="https://example.test/happy-together.jpg",
                    directors=[{"name": "Wong Kar-wai"}],
                    genres=[{"name": "Drama"}],
                ),
            ]
        )
        db.session.commit()

    page.set_viewport_size({"width": 1440, "height": 900})
    sign_in(page, live_app)
    page.goto(f"{live_app}/movies")
    discovery = page.locator("#movie-discovery")
    assert discovery.is_visible()
    discovery_box = discovery.bounding_box()
    filters_box = page.locator(".filter-bar").bounding_box()
    assert discovery_box and filters_box
    assert abs(discovery_box["x"] - filters_box["x"]) <= 1
    assert abs(discovery_box["width"] - filters_box["width"]) <= 1
    filters = page.get_by_role("button", name="More filters")
    filters.click()
    filter_dialog = page.locator("#movie-filter-dialog")
    filter_dialog.wait_for(state="visible")
    assert filter_dialog.evaluate("dialog => dialog.open") is True
    assert filter_dialog.get_by_role("button", name="Apply filters").is_visible()
    page.keyboard.press("Escape")
    filter_dialog.wait_for(state="hidden")
    assert page.evaluate("() => document.activeElement?.textContent?.includes('More filters')")

    page.get_by_role("button", name="What should I watch?").click()
    recommendation = page.locator("[data-recommendation-card]")
    recommendation.wait_for(state="visible")
    first_title = recommendation.locator("h2").inner_text()
    page.get_by_role("button", name="Try another").click()
    assert recommendation.locator("h2").inner_text() != first_title
    second_title = recommendation.locator("h2").inner_text()

    page.reload()

    assert recommendation.locator("h2").inner_text() != second_title


def test_movie_recommendation_try_another_switches_the_pick(page, live_app, app):
    with app.app_context():
        db.session.add_all(
            [
                Movie(
                    title="First pick",
                    normalized_title="first pick",
                    year=1994,
                    status="want_to_watch",
                    category="movie",
                    source="My library",
                    overview="A complete recommendation candidate.",
                    poster_url="https://example.test/first.jpg",
                    directors=[{"name": "A director"}],
                    genres=[{"name": "Drama"}],
                ),
                Movie(
                    title="Second pick",
                    normalized_title="second pick",
                    year=1997,
                    status="want_to_watch",
                    category="movie",
                    source="My library",
                    overview="Another complete recommendation candidate.",
                    poster_url="https://example.test/second.jpg",
                    directors=[{"name": "A director"}],
                    genres=[{"name": "Drama"}],
                ),
            ]
        )
        db.session.commit()

    sign_in(page, live_app)
    page.goto(f"{live_app}/movies")
    recommendation = page.locator("[data-recommendation-card]")
    first_title = recommendation.locator("h2").inner_text()
    first_overview = recommendation.locator("[data-recommendation-overview]").inner_text()
    assert first_overview in {
        "A complete recommendation candidate.",
        "Another complete recommendation candidate.",
    }

    page.get_by_role("button", name="Try another").click()

    assert recommendation.locator("h2").inner_text() != first_title
    assert recommendation.locator("[data-recommendation-overview]").inner_text() != first_overview


def test_movie_discovery_opens_series_detail_and_seeded_release(page, live_app, app):
    class StubTmdbProvider:
        def details(self, media_type, tmdb_id):
            assert (media_type, tmdb_id) == ("tv", 1399)
            return {
                "tmdb_id": 1399,
                "media_type": "tv",
                "title": "Game of Thrones",
                "original_title": "Game of Thrones",
                "year": 2011,
                "overview": "Nine noble families fight for control.",
                "poster_url": "",
                "runtime_minutes": 55,
                "genres": [{"name": "Drama"}],
                "directors": [],
                "cast": [],
                "external_ids": {"tmdb_id": "1399", "tmdb_type": "tv"},
                "seasons": [{"season_number": 1, "name": "Season 1", "episode_count": 10}],
            }

    with app.app_context():
        app.extensions["dragon_tmdb_catalog_provider"] = StubTmdbProvider()

    page.route(
        "**/movies/api/search?*",
        lambda route: route.fulfill(
            json={
                "ok": True,
                "library": [],
                "discovery": [
                    {
                        "tmdb_id": 1399,
                        "media_type": "tv",
                        "title": "Game of Thrones",
                        "year": 2011,
                        "overview": "Nine noble families fight for control.",
                        "poster_url": "",
                        "in_library": False,
                        "local_id": None,
                        "detail_url": f"{live_app}/movies/discover/tv/1399",
                    }
                ],
                "library_error": "",
            }
        ),
    )
    page.route(
        "**/movies/api/tv/1399/seasons",
        lambda route: route.fulfill(
            json={
                "ok": True,
                "items": [
                    {
                        "name": "Season 1",
                        "season_number": 1,
                        "episode_count": 10,
                    }
                ],
            }
        ),
    )
    page.route(
        "**/movies/api/tv/1399/seasons/1/episodes",
        lambda route: route.fulfill(
            json={
                "ok": True,
                "items": [{"name": "Winter Is Coming", "episode_number": 1}],
            }
        ),
    )
    page.route(
        "**/movies/api/releases?*",
        lambda route: route.fulfill(
            json={
                "ok": True,
                "items": [
                    {
                        "title": "Game.of.Thrones.S01E01.1080p",
                        "magnet_uri": "magnet:?xt=urn:btih:AAAA",
                        "seeders": 42,
                        "size": 1_500_000_000,
                        "tracker": "1337x",
                    }
                ],
            }
        ),
    )

    page.set_viewport_size({"width": 390, "height": 844})
    sign_in(page, live_app)
    page.goto(f"{live_app}/movies")
    page.locator("[data-discovery-query]").fill("Game of Thrones")
    page.get_by_role("button", name="Search", exact=True).click()
    page.get_by_role("link", name="Open series").click()

    page.wait_for_url(f"{live_app}/movies/discover/tv/1399")
    assert page.get_by_role("heading", name="Game of Thrones", level=1).count() == 1
    page.locator("[data-season-select]").select_option("1")
    page.locator("[data-episode-select] option[value='1']").wait_for(state="attached")
    page.locator("[data-episode-select]").select_option("1")
    page.get_by_text("Game.of.Thrones.S01E01.1080p").wait_for()
    assert page.get_by_text("42 seeders", exact=False).count() == 1
    assert page.get_by_role("button", name="+ Add season 1 to Notion").is_visible()
    assert page.get_by_role("button", name="Add to Notion & play").is_visible()
    assert page.evaluate(
        "document.documentElement.scrollWidth === document.documentElement.clientWidth"
    )


def test_vidsrc_player_loads_only_after_explicit_click(page, live_app, app):
    with app.app_context():
        movie = Movie(
            title="Arrival",
            normalized_title="arrival",
            external_ids={"imdb_id": "tt2543164"},
        )
        db.session.add(movie)
        db.session.commit()
        movie_id = movie.id

    app.config["DRAGON_PLAYBACK_ENABLED"] = True
    app.config["DRAGON_VIDSRC_ENABLED"] = True
    app.config["DRAGON_VIDSRC_EMBED_URL"] = "https://vsembed.ru/embed"
    page.route(
        "https://vsembed.ru/**",
        lambda route: route.fulfill(
            content_type="text/html",
            body="<main><h1>VidSrc test player</h1></main>",
        ),
    )

    sign_in(page, live_app)
    page.goto(f"{live_app}/movies/{movie_id}")
    frame = page.locator("[data-player-frame]")
    assert frame.is_hidden()
    assert page.locator("[data-player-controls]").is_hidden()
    page.get_by_role("button", name="Play with VidSrc").click()
    page.frame_locator("[data-player-frame]").get_by_role(
        "heading", name="VidSrc test player"
    ).wait_for()
    assert frame.is_visible()
    assert page.locator("[data-player-launch]").is_hidden()
    assert page.locator("[data-player-controls]").is_visible()
    assert page.get_by_text("VidSrc loaded.", exact=False).is_visible()


@pytest.mark.parametrize(
    ("path", "heading"),
    [
        ("/", "Today"),
        ("/movies", "Movies"),
        ("/youtube", "YouTube"),
        ("/reading", "News"),
        ("/books", "Books"),
        ("/books/reading", "Reading"),
        ("/books/finished", "Finished"),
        ("/books/wishlist", "Wishlist"),
        ("/books/paused", "Paused"),
        ("/books/dropped", "Dropped"),
        ("/books/reference", "Reference"),
        ("/books/audiobooks", "Audiobooks"),
        ("/books/collections", "Collections"),
        ("/books/needs-review", "Needs Review"),
        ("/books/metadata/inbox", "Metadata Inbox"),
        ("/books/metadata/verified", "Verified Metadata"),
        ("/books/metadata/no-isbn", "No ISBN"),
        ("/books/metadata/errors", "Metadata Errors"),
        ("/books/formats/kfx", "Has KFX"),
        ("/books/formats/azw3", "Has AZW3"),
        ("/books/formats/epub", "Has EPUB"),
        ("/books/formats/pdf", "Has PDF"),
        ("/books/formats/pdf-only", "PDF Only"),
        ("/books/formats/no-digital", "No Digital Format"),
        ("/books/signals/highlights", "Has Highlights"),
        ("/books/signals/quotes", "Has Quotes"),
        ("/books/signals/notes", "Has Notes"),
        ("/books/highlights", "Highlights"),
        ("/books/quotes", "Quotes"),
        ("/chess", "Chess"),
        ("/german", "German"),
        ("/history", "History"),
        ("/admin", "Control Center"),
        ("/ai/workspace", "Movie Curation"),
    ],
)
def test_primary_pages_mobile_accessibility_and_overflow(page, live_app, path, heading):
    page.set_viewport_size({"width": 390, "height": 844})
    sign_in(page, live_app)
    page.goto(f"{live_app}{path}")
    assert page.get_by_role("heading", name=heading, level=1).count() == 1
    assert page.locator("main").count() == 1
    assert page.locator("[style]").count() == 0
    metrics = page.evaluate(
        """() => ({
          scrollWidth: document.documentElement.scrollWidth,
          clientWidth: document.documentElement.clientWidth,
          unlabeled: [...document.querySelectorAll('input:not([type=hidden]), select, textarea')]
            .filter((element) => !element.closest('label') && !element.getAttribute('aria-label'))
            .length,
        })"""
    )
    assert metrics["scrollWidth"] == metrics["clientWidth"]
    assert metrics["unlabeled"] == 0
